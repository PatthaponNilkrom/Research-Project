% Comment
function ret=myfunction(a,b,c)

ret=a


