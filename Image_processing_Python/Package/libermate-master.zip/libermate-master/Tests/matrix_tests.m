% Create matrices using row and column join
% row -> commas, spaces
% column -> semicolons, newlines

a=[1,2,3;4,5,6]
b=[1 2 3;4 5 6]
c=[1 2 3
4 5 6]
% ignore initial and final returns
d=[
 1 2 3
 4 5 6
 ]

