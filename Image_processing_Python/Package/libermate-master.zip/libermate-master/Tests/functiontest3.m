% Comment
function ret=myfunction(a,b,c)

ret=a
% Comment
function [ret,b]=myfunction1(a,b,c)

ret=a


% Comment
function [ret,ret2,ret3]=myfunction1(a,b,c)

if(1)
    return
end
ret=a




