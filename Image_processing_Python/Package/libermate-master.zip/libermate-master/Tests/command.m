
% Command options
hold('on')
hold on
hold off


