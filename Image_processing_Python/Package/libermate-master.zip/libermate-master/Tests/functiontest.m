function myfunction(a,b,c)

h=a

