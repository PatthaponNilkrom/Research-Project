NumPy has a Code of Conduct, please see: https://numpy.org/code-of-conduct
