:orphan:

===========================
Array Broadcasting in Numpy
===========================

.. 
   Originally part of the scipy.org wiki, available `here
   <https://scipy.github.io/old-wiki/pages/EricsBroadcastingDoc>`_ or from the
   `github repo
   <https://github.com/scipy/old-wiki/blob/gh-pages/pages/EricsBroadcastingDoc.html>`_

.. note::
    Please refer to the updated :doc:`basics.broadcasting` document.

