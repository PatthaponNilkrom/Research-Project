.. _user_guide:

==========
User Guide
==========

Skip to the :ref:`load_tutorial` tutorial if you already have HoloPy installed
and want to get started quickly.

.. toctree::
   :maxdepth: 1

   scatterers
   theories
   tools
   concepts
